package com.example.InsuranceSystem.DTO;

import com.example.InsuranceSystem.Enums.ClaimStatus;
import com.example.InsuranceSystem.model.MemberCreation;


public class ClaimRequestDTO {
    private MemberCreation member;
	public MemberCreation getMemeber() {
		return member;
	}
	public void setMemeber(MemberCreation memeber) {
		this.member = memeber;
	}
	public int getClaimDate() {
		return claimDate;
	}
	public void setClaimDate(int claimDate) {
		this.claimDate = claimDate;
	}
	public int getClaimAmount() {
		return claimAmount;
	}
	public void setClaimAmount(int claimAmount) {
		this.claimAmount = claimAmount;
	}
	public ClaimStatus getClaimstatus() {
		return claimstatus;
	}
	public void setClaimstatus(ClaimStatus claimstatus) {
		this.claimstatus = claimstatus;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	private int claimDate;
	private int claimAmount;
	private ClaimStatus claimstatus;
	private String description;

}
