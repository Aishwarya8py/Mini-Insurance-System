package com.example.InsuranceSystem.Enums;

public enum PaymentStatus {
	ACTIVE,
	INACTIVE

}
