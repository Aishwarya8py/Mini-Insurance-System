package com.example.InsuranceSystem.model;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@DiscriminatorValue("SINGLE")
public class DependencySingle extends MemberCreation {
	private String fatherName;
	private String fatherdob;
	private String fatherpancardNo;
	
	private String motherName;
	private String motherdob;
	private String motherpancardNo;
	
	public String getFatherName() {
		return fatherName;
	}
	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}
	public String getFatherdob() {
		return fatherdob;
	}
	public void setFatherdob(String fatherdob) {
		this.fatherdob = fatherdob;
	}
	public String getFatherpancardNo() {
		return fatherpancardNo;
	}
	public void setFatherpancardNo(String fatherpancardNo) {
		this.fatherpancardNo = fatherpancardNo;
	}
	public String getMotherName() {
		return motherName;
	}
	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}
	public String getMotherdob() {
		return motherdob;
	}
	public void setMotherdob(String motherdob) {
		this.motherdob = motherdob;
	}
	public String getMotherpancardNo() {
		return motherpancardNo;
	}
	public void setMotherpancardNo(String motherpancardNo) {
		this.motherpancardNo = motherpancardNo;
	}
	

}
