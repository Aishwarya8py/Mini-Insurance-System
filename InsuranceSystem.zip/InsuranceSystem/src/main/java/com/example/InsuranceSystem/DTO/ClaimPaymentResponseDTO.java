package com.example.InsuranceSystem.DTO;

import com.example.InsuranceSystem.Enums.PaymentProcessingStatus;


public class ClaimPaymentResponseDTO {
	private int claimPaymentId;
	public int getClaimPaymentId() {
		return claimPaymentId;
	}

	public void setClaimPaymentId(int claimPaymentId) {
		this.claimPaymentId = claimPaymentId;
	}

	public String getClaimpaymentDate() {
		return claimpaymentDate;
	}

	public void setClaimpaymentDate(String claimpaymentDate) {
		this.claimpaymentDate = claimpaymentDate;
	}

	public double getAmountPaid() {
		return amountPaid;
	}

	public void setAmountPaid(double amountPaid) {
		this.amountPaid = amountPaid;
	}

	public PaymentProcessingStatus getPaymentProcessingStatus() {
		return paymentProcessingStatus;
	}

	public void setPaymentProcessingStatus(PaymentProcessingStatus paymentProcessingStatus) {
		this.paymentProcessingStatus = paymentProcessingStatus;
	}

	public int getClaimId() {
		return claimId;
	}

	public void setClaimId(int claimId) {
		this.claimId = claimId;
	}

	public int getMemberId() {
		return memberId;
	}

	public void setMemberId(int memberId) {
		this.memberId = memberId;
	}

	public int getGroupId() {
		return groupId;
	}

	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}

	private int claimId;
	private int memberId;
	private int groupId;
	private String claimpaymentDate;
	private double amountPaid;
	private PaymentProcessingStatus paymentProcessingStatus;


}
