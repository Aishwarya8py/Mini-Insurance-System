package com.example.InsuranceSystem.DTO;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class MemberResponseDTO {

    public Integer getMemberId() {
		return memberId;
	}
	public void setMemberId(Integer memberId) {
		this.memberId = memberId;
	}
	public Integer getGroupId() {
		return groupId;
	}
	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}
	public String getMemberName() {
		return memberName;
	}
	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getEnrollmentDate() {
		return enrollmentDate;
	}
	public void setEnrollmentDate(String enrollmentDate) {
		this.enrollmentDate = enrollmentDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDependencyType() {
		return dependencyType;
	}
	public void setDependencyType(String dependencyType) {
		this.dependencyType = dependencyType;
	}
	public String getSpouseName() {
		return spouseName;
	}
	public void setSpouseName(String spouseName) {
		this.spouseName = spouseName;
	}
	public String getSpousedob() {
		return spousedob;
	}
	public void setSpousedob(String spousedob) {
		this.spousedob = spousedob;
	}
	public String getSpousepancardNo() {
		return spousepancardNo;
	}
	public void setSpousepancardNo(String spousepancardNo) {
		this.spousepancardNo = spousepancardNo;
	}
	public String getFatherName() {
		return fatherName;
	}
	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}
	public String getFatherdob() {
		return fatherdob;
	}
	public void setFatherdob(String fatherdob) {
		this.fatherdob = fatherdob;
	}
	public String getFatherpancardNo() {
		return fatherpancardNo;
	}
	public void setFatherpancardNo(String fatherpancardNo) {
		this.fatherpancardNo = fatherpancardNo;
	}
	public String getMotherName() {
		return motherName;
	}
	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}
	public String getMotherdob() {
		return motherdob;
	}
	public void setMotherdob(String motherdob) {
		this.motherdob = motherdob;
	}
	public String getMotherpancardNo() {
		return motherpancardNo;
	}
	public void setMotherpancardNo(String motherpancardNo) {
		this.motherpancardNo = motherpancardNo;
	}
	private Integer memberId;
    private Integer groupId;
    private String memberName;
    private String dob;
    private String enrollmentDate;
    private String status;
    private String dependencyType;

    // Married
    private String spouseName;
    private String spousedob;
    private String spousepancardNo;

    // Single
    private String fatherName;
    private String fatherdob;
    private String fatherpancardNo;
    private String motherName;
    private String motherdob;
    private String motherpancardNo;

    // getters & setters omitted for brevity
}

