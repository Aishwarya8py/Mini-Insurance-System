package com.example.InsuranceSystem.Service;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.InsuranceSystem.DTO.GroupRequestDTO;
import com.example.InsuranceSystem.DTO.GroupResponseDTO;
import com.example.InsuranceSystem.Repositories.GroupRepository;
import com.example.InsuranceSystem.model.GroupCreation;

@Service
public class GroupService {
	@Autowired

	private GroupRepository groupRepository;

	@Autowired

	private ModelMapper modelMapper;

	public GroupResponseDTO createGroup (GroupRequestDTO dto) {

	GroupCreation group= modelMapper.map(dto, GroupCreation.class);
	GroupCreation saved =groupRepository.save(group);
	

	return modelMapper.map(saved, GroupResponseDTO.class);

	}

	public List<GroupResponseDTO> getAllGroups(){
	return groupRepository.findAll()
			.stream() 
			.map(group-> modelMapper.map(group, GroupResponseDTO.class)) 
		    .collect(Collectors.toList());
	}
	public GroupResponseDTO getGroupById(int groupId) {

	GroupCreation group= groupRepository.findById(groupId)

	.orElseThrow(()-> new RuntimeException("Group not found with thid id:"+groupId)); 
	return modelMapper.map(group, GroupResponseDTO.class);

	}

	public GroupResponseDTO updateGroup(int groupId, GroupRequestDTO dto) {
	GroupCreation existing = groupRepository.findById(groupId)
          .orElseThrow(()-> new RuntimeException("Group not found"));
	modelMapper.map(dto,existing);
	GroupCreation updated = groupRepository.save(existing);
	return modelMapper.map(updated, GroupResponseDTO.class);
	}
	/*

	existing.setGroupName (updatedGroup.getGroupName());

	existing.setCoverageDetails(updatedGroup.getCoverageDetails());

	existing.setDate(updatedGroup.getDate());

	existing.setGroupType (updatedGroup.getGroupType());

	I

	Contact updatedContact = updatedGroup.getContact();

	if (updatedContact != null) {

	existing.getContact().setContactId(updatedContact.getContactId());

	existing.getContact().setPhoneNo (updatedContact.getPhoneNo());

	existing.getContact().setAddress(updatedContact.getAddress());

	existing.getContact().setEmail(updatedContact.getEmail());

	} return groupRepository.save(existing);

	
*/
	public void DeleteGroup(int groupId) {

	

	groupRepository.deleteById(groupId);
}		
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			

}
