package com.example.InsuranceSystem.Controller;

import com.example.InsuranceSystem.DTO.BenefitRequestDTO;
import com.example.InsuranceSystem.DTO.BenefitResponseDTO;
import com.example.InsuranceSystem.Service.BenefitService;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/api/benefits")
public class BenefitController {

    @Autowired
    private BenefitService benefitService;

    // ✅ CREATE
    @PostMapping("/group/{groupId}")
    public ResponseEntity<BenefitResponseDTO> addBenefitToGroup(
            @PathVariable int groupId,
            @Valid @RequestBody BenefitRequestDTO benefitRequestDTO) {
        try {
            BenefitResponseDTO response = benefitService.addBenefitToGroup(groupId, benefitRequestDTO);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (RuntimeException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, ex.getMessage());
        }
    }

    // ✅ READ ALL
    @GetMapping
    public ResponseEntity<List<BenefitResponseDTO>> getAllBenefits() {
        return ResponseEntity.ok(benefitService.getAllBenefits());
    }

    // ✅ READ BY ID
    @GetMapping("/{benefitId}")
    public ResponseEntity<BenefitResponseDTO> getBenefitById(@PathVariable int benefitId) {
        try {
            return ResponseEntity.ok(benefitService.getBenefitById(benefitId));
        } catch (RuntimeException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, ex.getMessage());
        }
    }

    // ✅ READ BY GROUP ID
    @GetMapping("/group/{groupId}")
    public ResponseEntity<List<BenefitResponseDTO>> getBenefitByGroupId(@PathVariable int groupId) {
        try {
            return ResponseEntity.ok(benefitService.getBenefitByGroupId(groupId));
        } catch (RuntimeException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, ex.getMessage());
        }
    }

    // ✅ UPDATE
    @PutMapping("/{benefitId}")
    public ResponseEntity<BenefitResponseDTO> updateBenefit(
            @PathVariable int benefitId,
            @Valid @RequestBody BenefitRequestDTO benefitRequestDTO) {
        try {
            BenefitResponseDTO updated = benefitService.updateBenefit(benefitId, benefitRequestDTO);
            return ResponseEntity.ok(updated);
        } catch (RuntimeException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, ex.getMessage());
        }
    }

    // ✅ DELETE
    @DeleteMapping("/{benefitId}")
    public ResponseEntity<String> deleteBenefit(@PathVariable int benefitId) {
        try {
            benefitService.deleteBenefit(benefitId);
            return ResponseEntity.ok("Benefit with ID " + benefitId + " deleted successfully.");
        } catch (RuntimeException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, ex.getMessage());
        }
    }
}
