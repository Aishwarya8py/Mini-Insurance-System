package com.example.InsuranceSystem.Enums;

public enum ContributionType {
	CONTRIBUTORY,
	NON_CONTRIBUTORY,
	VOLUNTARY

}
