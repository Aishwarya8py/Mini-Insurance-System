package com.example.InsuranceSystem.Service;

import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;

import com.example.InsuranceSystem.DTO.BenefitRequestDTO;
import com.example.InsuranceSystem.DTO.BenefitResponseDTO;
import com.example.InsuranceSystem.DTO.ClaimRequestDTO;
import com.example.InsuranceSystem.DTO.ClaimResponseDTO;
import com.example.InsuranceSystem.DTO.MemberRequestDTO;
import com.example.InsuranceSystem.DTO.MemberResponseDTO;
import com.example.InsuranceSystem.Repositories.BenefitRepository;
import com.example.InsuranceSystem.Repositories.ClaimsRepository;
import com.example.InsuranceSystem.Repositories.GroupRepository;
import com.example.InsuranceSystem.Repositories.MemberRepository;
import com.example.InsuranceSystem.model.BenefitPolicyCreation;
import com.example.InsuranceSystem.model.Claims;
import com.example.InsuranceSystem.model.DependencyMarried;
import com.example.InsuranceSystem.model.DependencySingle;
import com.example.InsuranceSystem.model.GroupCreation;
import com.example.InsuranceSystem.model.MemberCreation;


@Service
public class ClaimService {
	@Autowired
	private ClaimsRepository claimRepository;

	@Autowired

	private MemberRepository memberRepository;

	@Autowired

	private ModelMapper modelMapper;

	public ClaimResponseDTO addClaimToMember(int memberId, ClaimRequestDTO cdto) {

	MemberCreation member =memberRepository.findById(memberId)
           .orElseThrow(()-> new RuntimeException("Member not found with this id no"+memberId));

	Claims claim = modelMapper.map(cdto, Claims.class);

	claim.setMember(member);

	Claims saved =claimRepository.save(claim);

	
	return modelMapper.map(saved, ClaimResponseDTO.class);
	}
	public List<ClaimResponseDTO> getAllClaims(){

	return claimRepository.findAll() 
			              .stream()
                          .map(claim-> modelMapper.map(claim, ClaimResponseDTO.class))
                          .collect(Collectors.toList());

	} 
	public ClaimResponseDTO getClaimById(int claimId) { 
	Claims claim =claimRepository.findById(claimId)
	        .orElseThrow(()-> new RuntimeException("Member not found with this memberId no:"+claimId));
	return modelMapper.map(claim, ClaimResponseDTO.class);
	}

	public List<ClaimResponseDTO> getClaimByMemberId(int memberId){
	return claimRepository.findById(memberId) 
			              .stream() 
			              .map(claim-> modelMapper.map(claim, ClaimResponseDTO.class)) 
			              .collect(Collectors.toList()); }

	public ClaimResponseDTO updateClaim(int claimId, ClaimRequestDTO cdto) {
	Claims existing= claimRepository.findById(claimId)
			.orElseThrow(()-> new RuntimeException ("claim not found with this id: "+claimId));
	modelMapper.map(cdto, existing); 
	Claims updated = claimRepository.save(existing); 
	return modelMapper.map(updated, ClaimResponseDTO.class);

	}
	public void deleteClaim (int claimId) { 
		claimRepository.deleteById(claimId);
		}

}
