package com.example.InsuranceSystem.Controller;

import com.example.InsuranceSystem.DTO.PremiumPaymentRequestDTO;
import com.example.InsuranceSystem.DTO.PremiumPaymentResponseDTO;
import com.example.InsuranceSystem.Service.PremiumPaymentService;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/api/premium-payments")
public class PremiumPaymentController {

    @Autowired
    private PremiumPaymentService premiumPaymentService;

   
    @PostMapping
    public ResponseEntity<PremiumPaymentResponseDTO> createPremiumPayment(
            @Valid @RequestBody PremiumPaymentRequestDTO requestDTO) {
        try {
            PremiumPaymentResponseDTO response = premiumPaymentService.createPremiumPayment(requestDTO);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception ex) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, ex.getMessage());
        }
    }

    // ✅ READ ALL
    @GetMapping
    public ResponseEntity<List<PremiumPaymentResponseDTO>> getAllPremiumPayments() {
        return ResponseEntity.ok(premiumPaymentService.getAllPremiumPayments());
    }

    // ✅ READ BY ID
    @GetMapping("/{paymentId}")
    public ResponseEntity<PremiumPaymentResponseDTO> getPremiumPaymentById(@PathVariable int paymentId) {
        try {
            return ResponseEntity.ok(premiumPaymentService.getPremiumPaymentById(paymentId));
        } catch (Exception ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, ex.getMessage());
        }
    }

    // ✅ UPDATE
    @PutMapping("/{paymentId}")
    public ResponseEntity<PremiumPaymentResponseDTO> updatePremiumPayment(
            @PathVariable int paymentId,
            @Valid @RequestBody PremiumPaymentRequestDTO requestDTO) {
        try {
            PremiumPaymentResponseDTO updated = premiumPaymentService.updatePremiumPayment(paymentId, requestDTO);
            return ResponseEntity.ok(updated);
        } catch (Exception ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, ex.getMessage());
        }
    }

    // ✅ DELETE
    @DeleteMapping("/{paymentId}")
    public ResponseEntity<String> deletePremiumPayment(@PathVariable int paymentId) {
        try {
            premiumPaymentService.deletePremiumPayment(paymentId);
            return ResponseEntity.ok("Premium payment with ID " + paymentId + " deleted successfully.");
        } catch (Exception ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, ex.getMessage());
        }
    }
}
