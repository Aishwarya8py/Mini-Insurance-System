package com.example.InsuranceSystem.Controller;

import com.example.InsuranceSystem.DTO.ClaimRequestDTO;
import com.example.InsuranceSystem.DTO.ClaimResponseDTO;
import com.example.InsuranceSystem.Service.ClaimService;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/api/claims")
public class ClaimController {

    @Autowired
    private ClaimService claimService;

    // ✅ CREATE
    @PostMapping("/member/{memberId}")
    public ResponseEntity<ClaimResponseDTO> addClaimToMember(
            @PathVariable int memberId,
            @Valid @RequestBody ClaimRequestDTO claimRequestDTO) {
        try {
            ClaimResponseDTO response = claimService.addClaimToMember(memberId, claimRequestDTO);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (RuntimeException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, ex.getMessage());
        }
    }

    // ✅ READ ALL
    @GetMapping
    public ResponseEntity<List<ClaimResponseDTO>> getAllClaims() {
        return ResponseEntity.ok(claimService.getAllClaims());
    }

    // ✅ READ BY ID
    @GetMapping("/{claimId}")
    public ResponseEntity<ClaimResponseDTO> getClaimById(@PathVariable int claimId) {
        try {
            return ResponseEntity.ok(claimService.getClaimById(claimId));
        } catch (RuntimeException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, ex.getMessage());
        }
    }

    // ✅ READ BY MEMBER ID
    @GetMapping("/member/{memberId}")
    public ResponseEntity<List<ClaimResponseDTO>> getClaimByMemberId(@PathVariable int memberId) {
        try {
            return ResponseEntity.ok(claimService.getClaimByMemberId(memberId));
        } catch (RuntimeException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, ex.getMessage());
        }
    }

    // ✅ UPDATE
    @PutMapping("/{claimId}")
    public ResponseEntity<ClaimResponseDTO> updateClaim(
            @PathVariable int claimId,
            @Valid @RequestBody ClaimRequestDTO claimRequestDTO) {
        try {
            ClaimResponseDTO updated = claimService.updateClaim(claimId, claimRequestDTO);
            return ResponseEntity.ok(updated);
        } catch (RuntimeException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, ex.getMessage());
        }
    }

    // ✅ DELETE
    @DeleteMapping("/{claimId}")
    public ResponseEntity<String> deleteClaim(@PathVariable int claimId) {
        try {
            claimService.deleteClaim(claimId);
            return ResponseEntity.ok("Claim with ID " + claimId + " deleted successfully.");
        } catch (RuntimeException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, ex.getMessage());
        }
    }
}
