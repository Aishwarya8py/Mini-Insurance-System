package com.example.InsuranceSystem.Service;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.InsuranceSystem.DTO.BenefitRequestDTO;
import com.example.InsuranceSystem.DTO.BenefitResponseDTO;
import com.example.InsuranceSystem.Repositories.BenefitRepository;
import com.example.InsuranceSystem.Repositories.GroupRepository;
import com.example.InsuranceSystem.model.BenefitPolicyCreation;
import com.example.InsuranceSystem.model.GroupCreation;

@Service
public class BenefitService {
	
    @Autowired
	private BenefitRepository benefitRepository;

	@Autowired

	private GroupRepository groupRepository;

	@Autowired

	private ModelMapper modelMapper;

	public BenefitResponseDTO addBenefitToGroup(int groupId, BenefitRequestDTO bdto) {

	GroupCreation group =groupRepository.findById(groupId)
         .orElseThrow(()-> new RuntimeException("Group not found with is id no.: "+groupId));

	BenefitPolicyCreation benefit = modelMapper.map(bdto, BenefitPolicyCreation.class);
	benefit.setGroup(group);
	BenefitPolicyCreation saved = benefitRepository.save(benefit);
	BenefitResponseDTO out = modelMapper.map(saved, BenefitResponseDTO.class);
	out.setBenefitId(saved.getBenefitId());
	out.setGroupId(saved.getGroup().getGroupId());
	return out;

	}

	public List<BenefitResponseDTO> getAllBenefits(){

	return benefitRepository.findAll()

	.stream()

	.map(benefit-> modelMapper.map(benefit, BenefitResponseDTO.class))

	.collect(Collectors.toList());

	}

	public BenefitResponseDTO getBenefitById(int benefitId) {

	BenefitPolicyCreation benefit = benefitRepository.findById(benefitId)

	.orElseThrow(()-> new RuntimeException("Member not found with this memberId no: "+benefitId));

	return modelMapper.map(benefit, BenefitResponseDTO.class);

	}
    public List<BenefitResponseDTO> getBenefitByGroupId(int groupId) {
	return benefitRepository.findById(groupId) 
	 		                .stream() 
			                .map(benefit-> modelMapper.map(benefit, BenefitResponseDTO.class)) 
			                .collect(Collectors.toList());

	//custom finder method

	}

	public BenefitResponseDTO updateBenefit(int benefitId, BenefitRequestDTO bdto) {
	BenefitPolicyCreation existing = benefitRepository.findById(benefitId) 
			.orElseThrow(()-> new RuntimeException ("Benefit not found with this id: "+benefitId));
	modelMapper.map(bdto, existing);
	BenefitPolicyCreation updated = benefitRepository.save(existing); 
	return modelMapper.map(updated, BenefitResponseDTO.class);

	}

	public void deleteBenefit (int benefitId) { 
		benefitRepository.deleteById(benefitId);
		

	}

}

