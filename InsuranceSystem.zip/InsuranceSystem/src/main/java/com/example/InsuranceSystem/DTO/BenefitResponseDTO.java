package com.example.InsuranceSystem.DTO;

import com.example.InsuranceSystem.Enums.PaymentFrequency;
//import com.example.InsuranceSystem.model.GroupCreation;

public class BenefitResponseDTO {
	private int benefitId;
	private int groupId;
	private String benefitType;
	private String description;
	private int amountLimit;
	private int coverageLimit;
	private int premiumRate;
	private int memberNo;
	private PaymentFrequency paymentFrequency;
	public String getBenefitType() {
		return benefitType;
	}
	public void setBenefitType(String benefitType) {
		this.benefitType = benefitType;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getAmountLimit() {
		return amountLimit;
	}
	public void setAmountLimit(int amountLimit) {
		this.amountLimit = amountLimit;
	}
	public int getCoverageLimit() {
		return coverageLimit;
	}
	public void setCoverageLimit(int coverageLimit) {
		this.coverageLimit = coverageLimit;
	}
	public int getPremiumRate() {
		return premiumRate;
	}
	public void setPremiumRate(int premiumRate) {
		this.premiumRate = premiumRate;
	}
	public int getMemberNo() {
		return memberNo;
	}
	public void setMemberNo(int memberNo) {
		this.memberNo = memberNo;
	}
	public PaymentFrequency getPaymentFrequency() {
		return paymentFrequency;
	}
	public void setPaymentFrequency(PaymentFrequency paymentFrequency) {
		this.paymentFrequency = paymentFrequency;
	}
	public int getBenefitId() {
		return benefitId;
	}
	public void setBenefitId(int benefitId) {
		this.benefitId = benefitId;
	}
	public int getGroupId() {
		return groupId;
	}
	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}
	
	

}
