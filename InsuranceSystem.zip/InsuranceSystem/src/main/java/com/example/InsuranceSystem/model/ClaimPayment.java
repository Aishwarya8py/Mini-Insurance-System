package com.example.InsuranceSystem.model;

import com.example.InsuranceSystem.Enums.PaymentProcessingStatus;

//import jakarta.persistence.Column;
import jakarta.persistence.Entity;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
@Entity
@Data
@Table(name="Insurance_ClaimPayment")
public class ClaimPayment {
	@Id

	@GeneratedValue(strategy=GenerationType.IDENTITY)

	private int claimPaymentId;
	@ManyToOne (fetch=FetchType.LAZY)
	@JoinColumn(name="claim_id", nullable = false)
	private Claims claim;

	@ManyToOne (fetch=FetchType.LAZY)
	@JoinColumn(name="member_id", nullable = false)
	private MemberCreation member;

	@ManyToOne (fetch=FetchType.LAZY)
	@JoinColumn(name="group_id", nullable = false)
	private GroupCreation group;

	@NotNull
	private String claimpaymentDate;

	@NotNull
	private double amountPaid;

	@Enumerated(EnumType.STRING)
	@NotNull
	private PaymentProcessingStatus paymentProcessingStatus;


	public int getClaimPaymentId() {
		return claimPaymentId;
	}

	public void setClaimPaymentId(int claimPaymentId) {
		this.claimPaymentId = claimPaymentId;
	}

	public Claims getClaim() {
		return claim;
	}

	public void setClaim(Claims claim) {
		this.claim = claim;
	}

	public MemberCreation getMember() {
		return member;
	}

	public void setMember(MemberCreation member) {
		this.member = member;
	}

	public GroupCreation getGroup() {
		return group;
	}

	public void setGroup(GroupCreation group) {
		this.group = group;
	}

	public String getClaimpaymentDate() {
		return claimpaymentDate;
	}

	public void setClaimpaymentDate(String claimpaymentDate) {
		this.claimpaymentDate = claimpaymentDate;
	}

	public double getAmountPaid() {
		return amountPaid;
	}

	public void setAmountPaid(double amountPaid) {
		this.amountPaid = amountPaid;
	}

	public PaymentProcessingStatus getPaymentProcessingStatus() {
		return paymentProcessingStatus;
	}

	public void setPaymentProcessingStatus(PaymentProcessingStatus paymentProcessingStatus) {
		this.paymentProcessingStatus = paymentProcessingStatus;
	}
}
	

