package com.example.InsuranceSystem.DTO;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class MemberRequestDTO {

    @NotNull(message="Group ID is required")
    private Integer groupId;

    public Integer getGroupId() {
		return groupId;
	}
	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}
	public String getMemberName() {
		return memberName;
	}
	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDependencyType() {
		return dependencyType;
	}
	public void setDependencyType(String dependencyType) {
		this.dependencyType = dependencyType;
	}
	public String getSpouseName() {
		return spouseName;
	}
	public void setSpouseName(String spouseName) {
		this.spouseName = spouseName;
	}
	public String getSpousedob() {
		return spousedob;
	}
	public void setSpousedob(String spousedob) {
		this.spousedob = spousedob;
	}
	public String getSpousepancardNo() {
		return spousepancardNo;
	}
	public void setSpousepancardNo(String spousepancardNo) {
		this.spousepancardNo = spousepancardNo;
	}
	public String getFatherName() {
		return fatherName;
	}
	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}
	public String getFatherdob() {
		return fatherdob;
	}
	public void setFatherdob(String fatherdob) {
		this.fatherdob = fatherdob;
	}
	public String getFatherpancardNo() {
		return fatherpancardNo;
	}
	public void setFatherpancardNo(String fatherpancardNo) {
		this.fatherpancardNo = fatherpancardNo;
	}
	public String getMotherName() {
		return motherName;
	}
	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}
	public String getMotherdob() {
		return motherdob;
	}
	public void setMotherdob(String motherdob) {
		this.motherdob = motherdob;
	}
	public String getMotherpancardNo() {
		return motherpancardNo;
	}
	public void setMotherpancardNo(String motherpancardNo) {
		this.motherpancardNo = motherpancardNo;
	}
	@NotBlank(message="Member name is required")
    private String memberName;

    @NotBlank(message="Date of birth is required")
    private String dob;

    // you can omit enrollmentDate on create, or set default in service
    private String enrollmentDate;

    @NotBlank(message="Status is required")
    private String status;

    @NotBlank(message="Dependency type is required")
    @Pattern(regexp="MARRIED|SINGLE", message="Dependency must be MARRIED or SINGLE")
    private String dependencyType;

    // --- Married fields ---
    private String spouseName;
    private String spousedob;
    private String spousepancardNo;

    // --- Single (parents) fields ---
    private String fatherName;
    private String fatherdob;
    private String fatherpancardNo;
    private String motherName;
    private String motherdob;
    private String motherpancardNo;
	public String getEnrollmentDate() {
		return enrollmentDate;
	}
	public void setEnrollmentDate(String enrollmentDate) {
		this.enrollmentDate = enrollmentDate;
	}

}
