package com.example.InsuranceSystem.Service;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;

import com.example.InsuranceSystem.DTO.BenefitRequestDTO;
import com.example.InsuranceSystem.DTO.BenefitResponseDTO;
import com.example.InsuranceSystem.DTO.ClaimPaymentRequestDTO;
import com.example.InsuranceSystem.DTO.ClaimPaymentResponseDTO;
import com.example.InsuranceSystem.DTO.ClaimRequestDTO;
import com.example.InsuranceSystem.DTO.ClaimResponseDTO;
import com.example.InsuranceSystem.DTO.MemberRequestDTO;
import com.example.InsuranceSystem.DTO.MemberResponseDTO;
import com.example.InsuranceSystem.Repositories.BenefitRepository;
import com.example.InsuranceSystem.Repositories.ClaimPaymentRepository;
import com.example.InsuranceSystem.Repositories.ClaimsRepository;
import com.example.InsuranceSystem.Repositories.GroupRepository;
import com.example.InsuranceSystem.Repositories.MemberRepository;
import com.example.InsuranceSystem.model.BenefitPolicyCreation;
import com.example.InsuranceSystem.model.ClaimPayment;
import com.example.InsuranceSystem.model.Claims;
import com.example.InsuranceSystem.model.DependencyMarried;
import com.example.InsuranceSystem.model.DependencySingle;
import com.example.InsuranceSystem.model.GroupCreation;
import com.example.InsuranceSystem.model.MemberCreation;

import jakarta.persistence.EntityNotFoundException;

@Service
public class ClaimPaymentService {
	@Autowired
	

	private ClaimPaymentRepository claimpaymentRepository;

	@Autowired

	private GroupRepository groupRepository;

	@Autowired

	private MemberRepository memberRepository;

	@Autowired

	private ClaimsRepository claimRepository;

	@Autowired

	private ModelMapper modelMapper;

	public List<ClaimPaymentResponseDTO> getAllClaimPayments(){

	return claimpaymentRepository.findAll() 
			                     .stream()
			                     .map(claimpayment ->modelMapper.map(claimpayment, ClaimPaymentResponseDTO.class)) 
			                     .collect(Collectors.toList());

	}

	public ClaimPaymentResponseDTO getClaimPaymentById(int claimPaymentId) {

	ClaimPayment cpayment = claimpaymentRepository.findById(claimPaymentId) 
			.orElseThrow(()-> new EntityNotFoundException("Payment Not Found"));
	return modelMapper.map(cpayment, ClaimPaymentResponseDTO.class);

	}

	public ClaimPaymentResponseDTO createClaimPayment (ClaimPaymentRequestDTO cdto) {

	//map incoming DTO to entity

	ClaimPayment cpayment = modelMapper.map(cdto, ClaimPayment.class);

	GroupCreation group= groupRepository.findById(cdto.getGroupId())
	.orElseThrow(()-> new EntityNotFoundException("Group not found ")); 
	MemberCreation member =memberRepository.findById(cdto.getMemberId())
	.orElseThrow(()-> new EntityNotFoundException("Member not Found"));

	Claims claim = claimRepository.findById(cdto.getClaimId())
			.orElseThrow(()-> new EntityNotFoundException("Benefit not found"));

	cpayment.setGroup(group);

	cpayment.setMember(member);

	cpayment.setClaim(claim);

	ClaimPayment saved = claimpaymentRepository.save(cpayment);

	return modelMapper.map(saved, ClaimPaymentResponseDTO.class);

	}

	public ClaimPaymentResponseDTO updateClaimPayment(int claimPaymentId, ClaimPaymentRequestDTO cdto) {

	ClaimPayment existing =claimpaymentRepository.findById(claimPaymentId) 
			.orElseThrow(()-> new EntityNotFoundException("Payment id not found: "+claimPaymentId));
	modelMapper.map(cdto, existing);
	existing.setGroup(groupRepository.getReferenceById(cdto.getGroupId()));
	existing.setMember(memberRepository.getReferenceById(cdto.getMemberId()));
	existing.setClaim(claimRepository.getReferenceById(cdto.getClaimId()));
	ClaimPayment updated = claimpaymentRepository.save(existing);

	return modelMapper.map(updated, ClaimPaymentResponseDTO.class);

	}

	public void deleteClaimPayment(int claimPaymentId) {
	claimpaymentRepository.deleteById(claimPaymentId);

}
}
