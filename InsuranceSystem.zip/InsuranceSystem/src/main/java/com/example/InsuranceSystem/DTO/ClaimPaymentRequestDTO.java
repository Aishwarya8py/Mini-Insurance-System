package com.example.InsuranceSystem.DTO;

import com.example.InsuranceSystem.Enums.PaymentProcessingStatus;
import com.example.InsuranceSystem.model.Claims;


public class ClaimPaymentRequestDTO {
	private Claims claim;
	public Claims getClaim() {
		return claim;
	}
	public void setClaim(Claims claim) {
		this.claim = claim;
	}
	
	public String getClaimpaymentDate() {
		return claimpaymentDate;
	}
	public void setClaimpaymentDate(String claimpaymentDate) {
		this.claimpaymentDate = claimpaymentDate;
	}
	public double getAmountPaid() {
		return amountPaid;
	}
	public void setAmountPaid(double amountPaid) {
		this.amountPaid = amountPaid;
	}
	public PaymentProcessingStatus getPaymentProcessingStatus() {
		return paymentProcessingStatus;
	}
	public void setPaymentProcessingStatus(PaymentProcessingStatus paymentProcessingStatus) {
		this.paymentProcessingStatus = paymentProcessingStatus;
	}
	public int getMemberId() {
		return memberId;
	}
	public void setMemberId(int memberId) {
		this.memberId = memberId;
	}
	public int getGroupId() {
		return groupId;
	}
	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}
	public int getClaimId() {
		return claimId;
	}
	public void setClaimId(int claimId) {
		this.claimId = claimId;
	}
	private int memberId;
	private int groupId;
	private int claimId;
	private String claimpaymentDate;
	private double amountPaid;
	private PaymentProcessingStatus paymentProcessingStatus;


}
