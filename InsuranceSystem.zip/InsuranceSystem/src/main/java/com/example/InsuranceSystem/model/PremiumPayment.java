package com.example.InsuranceSystem.model;
import com.example.InsuranceSystem.Enums.ContributionType;
import com.example.InsuranceSystem.Enums.PaymentFrequency;
import com.example.InsuranceSystem.Enums.PaymentProcessingStatus;

//import jakarta.persistence.Column;
import jakarta.persistence.Entity;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
@Entity
@Data
@Table(name="Insurance_PremiumPayment")
public class PremiumPayment {
	@Id

	@GeneratedValue(strategy=GenerationType.IDENTITY)

	private int premiumPaymentId;
	@NotNull
	private int premiumPaymentDate;

	private double paymentAmount;

	@Enumerated(EnumType.STRING)

	@NotNull

	private PaymentFrequency paymentFrequency;

	@Enumerated(EnumType.STRING)

	@NotNull

	private ContributionType contributionType;

	@Enumerated(EnumType.STRING)

	@NotNull

	private PaymentProcessingStatus paymentProcessingStatus;

	@ManyToOne (fetch= FetchType.LAZY)

	@JoinColumn(name="groupId", nullable =false)

	private GroupCreation group;

	
	@ManyToOne(fetch= FetchType.LAZY)
	@JoinColumn(name="memberId", nullable=false)
	private MemberCreation member;

	@ManyToOne(fetch= FetchType.LAZY)
	@JoinColumn(name="benefitId", nullable= false)
	private BenefitPolicyCreation benefit;


	public int getPremiumPaymentId() {
		return premiumPaymentId;
	}

	public void setPremiumPaymentId(int premiumPaymentId) {
		this.premiumPaymentId = premiumPaymentId;
	}

	public int getPremiumPaymentDate() {
		return premiumPaymentDate;
	}

	public void setPremiumPaymentDate(int premiumPaymentDate) {
		this.premiumPaymentDate = premiumPaymentDate;
	}

	public double getPaymentAmount() {
		return paymentAmount;
	}

	public void setPaymentAmount(double paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	public PaymentFrequency getPaymentFrequency() {
		return paymentFrequency;
	}

	public void setPaymentFrequency(PaymentFrequency paymentFrequency) {
		this.paymentFrequency = paymentFrequency;
	}

	public ContributionType getContributionType() {
		return contributionType;
	}

	public void setContributionType(ContributionType contributionType) {
		this.contributionType = contributionType;
	}

	public PaymentProcessingStatus getPaymentProcessingStatus() {
		return paymentProcessingStatus;
	}

	public void setPaymentProcessingStatus(PaymentProcessingStatus paymentProcessingStatus) {
		this.paymentProcessingStatus = paymentProcessingStatus;
	}

	public GroupCreation getGroup() {
		return group;
	}

	public void setGroup(GroupCreation group) {
		this.group = group;
	}

	public MemberCreation getMember() {
		return member;
	}

	public void setMember(MemberCreation member) {
		this.member = member;
	}

	public BenefitPolicyCreation getBenefit() {
		return benefit;
	}

	public void setBenefit(BenefitPolicyCreation benefit) {
		this.benefit = benefit;
	}

	
}
