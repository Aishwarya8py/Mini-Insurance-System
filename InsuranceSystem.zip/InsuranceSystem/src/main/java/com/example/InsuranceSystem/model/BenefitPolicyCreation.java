package com.example.InsuranceSystem.model;

import com.example.InsuranceSystem.Enums.PaymentFrequency;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name="Insurance_Benefit")
public class BenefitPolicyCreation {
	@Id
	@GeneratedValue(strategy =GenerationType.IDENTITY)
	private int benefitId;
	
	@ManyToOne(fetch= FetchType.LAZY)
	@JoinColumn(name ="group_id", nullable = false)
	private GroupCreation group;
	
	private String benefitType;
	private String description;
	private int amountLimit;
	private int coverageLimit;
	private int premiumRate;
	private int memberNo;
	@Enumerated(EnumType.STRING)
	@Column(name="payment_frequency", nullable=false)
	private PaymentFrequency paymentFrequency;
	
	public int getBenefitId() {
		return benefitId;
	}
	public void setBenefitId(int benefitId) {
		this.benefitId = benefitId;
	}
	public GroupCreation getGroup() {
		return group;
	}
	public void setGroup(GroupCreation group) {
		this.group = group;
	}
	public String getBenefitType() {
		return benefitType;
	}
	public void setBenefitType(String benefitType) {
		this.benefitType = benefitType;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getAmountLimit() {
		return amountLimit;
	}
	public void setAmountLimit(int amountLimit) {
		this.amountLimit = amountLimit;
	}
	public int getCoverageLimit() {
		return coverageLimit;
	}
	public void setCoverageLimit(int coverageLimit) {
		this.coverageLimit = coverageLimit;
	}
	public int getPremiumRate() {
		return premiumRate;
	}
	public void setPremiumRate(int premiumRate) {
		this.premiumRate = premiumRate;
	}
	public int getMemberNo() {
		return memberNo;
	}
	public void setMemberNo(int memberNo) {
		this.memberNo = memberNo;
	}
	public PaymentFrequency getPaymentFrequency() {
		return paymentFrequency;
	}
	public void setPaymentFrequency(PaymentFrequency paymentFrequency) {
		this.paymentFrequency = paymentFrequency;
	}
	
	

}
