package com.example.InsuranceSystem.Controller;

import com.example.InsuranceSystem.DTO.MemberRequestDTO;
import com.example.InsuranceSystem.DTO.MemberResponseDTO;
import com.example.InsuranceSystem.Service.MemberService;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/api/members")
public class MemberController {

    @Autowired
    private MemberService memberService;

    // ✅ CREATE
    @PostMapping("/group/{groupId}")
    public ResponseEntity<MemberResponseDTO> addMemberToGroup(
            @PathVariable int groupId,
            @Valid @RequestBody MemberRequestDTO requestDTO) {
        try {
            MemberResponseDTO response = memberService.addMemberToGroup(groupId, requestDTO);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (RuntimeException ex) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, ex.getMessage());
        }
    }

    // ✅ READ ALL
    @GetMapping
    public ResponseEntity<List<MemberResponseDTO>> getAllMembers() {
        return ResponseEntity.ok(memberService.getAllMembers());
    }

    // ✅ READ BY ID
    @GetMapping("/{memberId}")
    public ResponseEntity<MemberResponseDTO> getMemberById(@PathVariable int memberId) {
        try {
            return ResponseEntity.ok(memberService.getMemberById(memberId));
        } catch (RuntimeException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, ex.getMessage());
        }
    }

    // ✅ READ BY GROUP ID
    @GetMapping("/group/{groupId}")
    public ResponseEntity<List<MemberResponseDTO>> getMemberByGroupId(@PathVariable int groupId) {
        try {
            return ResponseEntity.ok(memberService.getMemberByGroupId(groupId));
        } catch (RuntimeException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, ex.getMessage());
        }
    }

    // ✅ UPDATE
    @PutMapping("/{memberId}")
    public ResponseEntity<MemberResponseDTO> updateMember(
            @PathVariable int memberId,
            @Valid @RequestBody MemberRequestDTO requestDTO) {
        try {
            MemberResponseDTO updated = memberService.updateMember(memberId, requestDTO);
            return ResponseEntity.ok(updated);
        } catch (RuntimeException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, ex.getMessage());
        }
    }

    // ✅ DELETE
    @DeleteMapping("/{memberId}")
    public ResponseEntity<String> deleteMember(@PathVariable int memberId) {
        try {
            memberService.deleteMember(memberId);
            return ResponseEntity.ok("Member with ID " + memberId + " deleted successfully.");
        } catch (RuntimeException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, ex.getMessage());
        }
    }
}
