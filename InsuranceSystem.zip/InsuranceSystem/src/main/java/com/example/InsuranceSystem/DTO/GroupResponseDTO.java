package com.example.InsuranceSystem.DTO;

import com.example.InsuranceSystem.Enums.ContributionType;
import com.example.InsuranceSystem.model.ContactDetails;

public class GroupResponseDTO {
	private int groupId;

	private String groupName;
	private String creationDate;
	private String CoverageDetails;	
	private ContributionType contributionType;
	private String groupType;
	private ContactDetails contact;
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}
	public String getCoverageDetails() {
		return CoverageDetails;
	}
	public void setCoverageDetails(String coverageDetails) {
		CoverageDetails = coverageDetails;
	}
	public ContributionType getContributionType() {
		return contributionType;
	}
	public void setContributionType(ContributionType contributionType) {
		this.contributionType = contributionType;
	}
	public String getGroupType() {
		return groupType;
	}
	public void setGroupType(String groupType) {
		this.groupType = groupType;
	}
	public ContactDetails getContact() {
		return contact;
	}
	public void setContact(ContactDetails contact) {
		this.contact = contact;
	}
	public int getGroupId() {
		return groupId;
	}
	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}
	


}
