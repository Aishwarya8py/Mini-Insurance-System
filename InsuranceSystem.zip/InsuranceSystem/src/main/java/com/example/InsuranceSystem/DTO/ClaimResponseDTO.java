package com.example.InsuranceSystem.DTO;

import com.example.InsuranceSystem.Enums.ClaimStatus;
import com.example.InsuranceSystem.model.MemberCreation;


public class ClaimResponseDTO {
	private int claimId;
    public int getClaimId() {
		return claimId;
	}
	public void setClaimId(int claimId) {
		this.claimId = claimId;
	}
	

	public int getClaimDate() {
		return claimDate;
	}
	public void setClaimDate(int claimDate) {
		this.claimDate = claimDate;
	}
	public int getClaimAmount() {
		return claimAmount;
	}
	public void setClaimAmount(int claimAmount) {
		this.claimAmount = claimAmount;
	}
	public ClaimStatus getClaimstatus() {
		return claimstatus;
	}
	public void setClaimstatus(ClaimStatus claimstatus) {
		this.claimstatus = claimstatus;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getMemberId() {
		return memberId;
	}
	public void setMemberId(int memberId) {
		this.memberId = memberId;
	}
	private int memberId;
	private int claimDate;
	private int claimAmount;
	private ClaimStatus claimstatus;
	private String description;

}
