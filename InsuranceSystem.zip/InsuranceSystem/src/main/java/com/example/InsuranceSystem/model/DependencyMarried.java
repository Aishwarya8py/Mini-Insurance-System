package com.example.InsuranceSystem.model;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@DiscriminatorValue("MARRIED")
public class DependencyMarried extends MemberCreation{
	private String spouseName;
	public String getSpouseName() {
		return spouseName;
	}
	public void setSpouseName(String spouseName) {
		this.spouseName = spouseName;
	}
	public String getSpousedob() {
		return spousedob;
	}
	public void setSpousedob(String spousedob) {
		this.spousedob = spousedob;
	}
	public String getSpousepancardNo() {
		return spousepancardNo;
	}
	public void setSpousepancardNo(String spousepancardNo) {
		this.spousepancardNo = spousepancardNo;
	}
	private String spousedob;
	private String spousepancardNo;

}
