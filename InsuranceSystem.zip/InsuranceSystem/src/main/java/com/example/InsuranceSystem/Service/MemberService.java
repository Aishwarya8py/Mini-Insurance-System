package com.example.InsuranceSystem.Service;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.InsuranceSystem.DTO.MemberRequestDTO;
import com.example.InsuranceSystem.DTO.MemberResponseDTO;
import com.example.InsuranceSystem.Repositories.GroupRepository;
import com.example.InsuranceSystem.Repositories.MemberRepository;
import com.example.InsuranceSystem.model.DependencyMarried;
import com.example.InsuranceSystem.model.DependencySingle;
import com.example.InsuranceSystem.model.GroupCreation;
import com.example.InsuranceSystem.model.MemberCreation;

@Service
public class MemberService {
	@Autowired
	private MemberRepository memberRepository;

	@Autowired

	private GroupRepository groupRepository;

	@Autowired

	private ModelMapper modelMapper;

	

	public MemberResponseDTO addMemberToGroup(int groupId, MemberRequestDTO dto) {

	GroupCreation group =groupRepository.findById(groupId)
	     .orElseThrow(()-> new RuntimeException("Group not found with is id no.: "+groupId));
    MemberCreation member;
	if("MARRIED".equalsIgnoreCase(dto.getDependencyType())) {
		member= modelMapper.map(dto, DependencyMarried.class);
	} 
	else {

	member =modelMapper.map(dto, DependencySingle.class);

	} 
    member.setGroup(group);//set the foreign key relation
	MemberCreation saved =memberRepository.save(member);
	MemberResponseDTO out =modelMapper.map(saved, MemberResponseDTO.class);

	out.setMemberId(saved.getMemberId()); 
	out.setGroupId(saved.getGroup().getGroupId());

	return out;
}
	//return modelMapper.map(saved, NewberllesponseOTO.class);

	public MemberResponseDTO getMemberById(int memberId) { 
		MemberCreation member= memberRepository.findById(memberId)
	          .orElseThrow(()-> new RuntimeException("Member not found with this memberId no:"+memberId));
	    return modelMapper.map(member, MemberResponseDTO.class);

	}
	

	public List<MemberResponseDTO> getAllMembers(){

	return memberRepository.findAll()
	                       .stream()
	                       .map(member -> modelMapper.map(member, MemberResponseDTO.class))
	                       .collect(Collectors.toList());

	}

	public List<MemberResponseDTO> getMemberByGroupId(int groupId) {
	return memberRepository.findById(groupId)
                           .stream()
                           .map(member -> modelMapper.map(member, MemberResponseDTO.class))
                           .collect(Collectors.toList());

	//custom finder method

	}

	public MemberResponseDTO updateMember(int memberId, MemberRequestDTO dto) {

	MemberCreation existing =memberRepository.findById(memberId)
                 .orElseThrow(()-> new RuntimeException ("Member not found with this id: "+memberId));

	modelMapper.map(dto, existing);

	MemberCreation updated = memberRepository.save(existing);

	return modelMapper.map(updated, MemberResponseDTO.class);

	/*

	//existing.setMemberId (updateMember.getMemberId());

	existing.setMembername (updateMember.getMembername());

	existing.setDate(updateMember.getDate());

	existing.setEnrollmentDate(updateMember.getEnrollmentDate());

	existing.setStatus(updateMember.getStatus());

	//existing.setGroup (updateMember.getGroup());

	return memberRepository.save(existing);

	*/
	}
	public void deleteMember(int memberId) {
	memberRepository.deleteById(memberId);
	}
}
