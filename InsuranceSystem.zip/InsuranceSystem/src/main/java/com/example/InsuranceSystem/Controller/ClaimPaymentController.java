package com.example.InsuranceSystem.Controller;

import com.example.InsuranceSystem.DTO.ClaimPaymentRequestDTO;
import com.example.InsuranceSystem.DTO.ClaimPaymentResponseDTO;
import com.example.InsuranceSystem.Service.ClaimPaymentService;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/api/claim-payments")
public class ClaimPaymentController {

    @Autowired
    private ClaimPaymentService claimPaymentService;

    // ✅ CREATE
    @PostMapping
    public ResponseEntity<ClaimPaymentResponseDTO> createClaimPayment(
            @Valid @RequestBody ClaimPaymentRequestDTO requestDTO) {
        try {
            ClaimPaymentResponseDTO response = claimPaymentService.createClaimPayment(requestDTO);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception ex) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, ex.getMessage());
        }
    }

    // ✅ READ ALL
    @GetMapping
    public ResponseEntity<List<ClaimPaymentResponseDTO>> getAllClaimPayments() {
        return ResponseEntity.ok(claimPaymentService.getAllClaimPayments());
    }

    // ✅ READ BY ID
    @GetMapping("/{claimPaymentId}")
    public ResponseEntity<ClaimPaymentResponseDTO> getClaimPaymentById(@PathVariable int claimPaymentId) {
        try {
            return ResponseEntity.ok(claimPaymentService.getClaimPaymentById(claimPaymentId));
        } catch (Exception ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, ex.getMessage());
        }
    }

    // ✅ UPDATE
    @PutMapping("/{claimPaymentId}")
    public ResponseEntity<ClaimPaymentResponseDTO> updateClaimPayment(
            @PathVariable int claimPaymentId,
            @Valid @RequestBody ClaimPaymentRequestDTO requestDTO) {
        try {
            ClaimPaymentResponseDTO updated = claimPaymentService.updateClaimPayment(claimPaymentId, requestDTO);
            return ResponseEntity.ok(updated);
        } catch (Exception ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, ex.getMessage());
        }
    }

    // ✅ DELETE
    @DeleteMapping("/{claimPaymentId}")
    public ResponseEntity<String> deleteClaimPayment(@PathVariable int claimPaymentId) {
        try {
            claimPaymentService.deleteClaimPayment(claimPaymentId);
            return ResponseEntity.ok("Claim payment with ID " + claimPaymentId + " deleted successfully.");
        } catch (Exception ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, ex.getMessage());
        }
    }
}
