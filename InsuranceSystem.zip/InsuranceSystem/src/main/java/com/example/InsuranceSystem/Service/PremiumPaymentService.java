package com.example.InsuranceSystem.Service;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.InsuranceSystem.DTO.PremiumPaymentRequestDTO;
import com.example.InsuranceSystem.DTO.PremiumPaymentResponseDTO;
import com.example.InsuranceSystem.Repositories.BenefitRepository;
import com.example.InsuranceSystem.Repositories.GroupRepository;
import com.example.InsuranceSystem.Repositories.MemberRepository;
import com.example.InsuranceSystem.Repositories.PremiumPaymentRepository;
import com.example.InsuranceSystem.model.BenefitPolicyCreation;
import com.example.InsuranceSystem.model.GroupCreation;
import com.example.InsuranceSystem.model.MemberCreation;
import com.example.InsuranceSystem.model.PremiumPayment;

import jakarta.persistence.EntityNotFoundException;

@Service
public class PremiumPaymentService {
	private PremiumPaymentRepository premiumpaymentRepository;

	@Autowired

	private GroupRepository groupRepository;

	@Autowired

	private MemberRepository memberRepository;

	@Autowired

	private BenefitRepository benefitRepository;

	@Autowired

	private ModelMapper modelMapper;

	

	public List<PremiumPaymentResponseDTO> getAllPremiumPayments(){

	return premiumpaymentRepository.findAll()

	.stream() .map(premiumpayment ->modelMapper.map(premiumpayment, PremiumPaymentResponseDTO.class)) .collect(Collectors.toList());

	}

	public PremiumPaymentResponseDTO getPremiumPaymentById(int premiumPaymentId) {

	PremiumPayment ppayment = premiumpaymentRepository.findById(premiumPaymentId) 
			.orElseThrow(()-> new EntityNotFoundException("Payment Not Found"));
	return modelMapper.map(ppayment, PremiumPaymentResponseDTO.class);

	}

	public PremiumPaymentResponseDTO createPremiumPayment (PremiumPaymentRequestDTO pdto) {

	//map incoming DTO to entity

	PremiumPayment ppayment = modelMapper.map(pdto, PremiumPayment.class);

	GroupCreation group =groupRepository.findById(pdto.getGroupId())
	        .orElseThrow(()-> new EntityNotFoundException("Group not found ")); 
	MemberCreation member= memberRepository.findById(pdto.getMemberId()) 
			.orElseThrow(()-> new EntityNotFoundException("Member not Found"));
	BenefitPolicyCreation benefit= benefitRepository.findById(pdto.getBenefitId())
	        .orElseThrow(()-> new EntityNotFoundException("Benefit not found"));

	ppayment.setGroup(group);

	ppayment.setMember(member);

	ppayment.setBenefit(benefit);

	PremiumPayment saved =premiumpaymentRepository.save(ppayment); 
	return modelMapper.map(saved,PremiumPaymentResponseDTO.class);

	} 
	public PremiumPaymentResponseDTO updatePremiumPayment(int premiumPaymentId, PremiumPaymentRequestDTO pdto) { 
		PremiumPayment existing =premiumpaymentRepository.findById(premiumPaymentId) 
				.orElseThrow(()-> new EntityNotFoundException("Payment id not found: "+premiumPaymentId));

	modelMapper.map(pdto, existing);
	existing.setGroup(groupRepository.getReferenceById(pdto.getGroupId())); 
	existing.setMember(memberRepository.getReferenceById(pdto.getMemberId())); 
	existing.setBenefit(benefitRepository.getReferenceById(pdto.getBenefitId()));

	premiumpaymentRepository.save(existing); 
	return modelMapper.map(existing,PremiumPaymentResponseDTO.class);

	}

	public void deletePremiumPayment(int premiumPaymentId) { 
		premiumpaymentRepository.deleteById(premiumPaymentId);
	}
	

}
