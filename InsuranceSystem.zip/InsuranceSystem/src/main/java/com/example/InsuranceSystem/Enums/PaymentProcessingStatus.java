package com.example.InsuranceSystem.Enums;

public enum PaymentProcessingStatus {
	PENDING,
	COMPLETED,
	FAILED

}
