package com.example.InsuranceSystem.ModelMapper;

import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeMap;
import org.modelmapper.convention.MatchingStrategies;
import org.modelmapper.config.Configuration.AccessLevel;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.example.InsuranceSystem.DTO.BenefitResponseDTO;
import com.example.InsuranceSystem.DTO.ClaimPaymentResponseDTO;
import com.example.InsuranceSystem.DTO.ClaimResponseDTO;
import com.example.InsuranceSystem.DTO.PremiumPaymentResponseDTO;
import com.example.InsuranceSystem.Enums.ClaimStatus;
import com.example.InsuranceSystem.Enums.ContributionType;
import com.example.InsuranceSystem.Enums.PaymentFrequency;
import com.example.InsuranceSystem.Enums.PaymentProcessingStatus;
import com.example.InsuranceSystem.Enums.PaymentStatus;
import com.example.InsuranceSystem.model.BenefitPolicyCreation;
import com.example.InsuranceSystem.model.ClaimPayment;
import com.example.InsuranceSystem.model.Claims;
import com.example.InsuranceSystem.model.PremiumPayment;


@Configuration
public class ModelMapperConfiguration {

    @Bean
    public ModelMapper modelMapper() {
        ModelMapper mapper = new ModelMapper();

        mapper.getConfiguration()
            .setMatchingStrategy(MatchingStrategies.STRICT)
            .setPropertyCondition(Conditions.isNotNull())
            .setFieldMatchingEnabled(true)
            .setFieldAccessLevel(AccessLevel.PRIVATE);

        // Benefit to DTO mapping
        mapper.typeMap(BenefitPolicyCreation.class, BenefitResponseDTO.class)
            .addMapping(src -> src.getGroup().getGroupId(), BenefitResponseDTO::setGroupId);

        // Claim to DTO mapping
        mapper.typeMap(Claims.class, ClaimResponseDTO.class)
            .addMapping(src -> src.getMember().getMemberId(), ClaimResponseDTO::setMemberId);

        // PremiumPayment to DTO mapping
        TypeMap<PremiumPayment, PremiumPaymentResponseDTO> typeMap = 
            mapper.createTypeMap(PremiumPayment.class, PremiumPaymentResponseDTO.class);

        typeMap.addMappings(resp -> {
            resp.map(src -> src.getGroup().getGroupId(), PremiumPaymentResponseDTO::setGroupId);
            resp.map(src -> src.getMember().getMemberId(), PremiumPaymentResponseDTO::setMemberId);
            resp.map(src -> src.getBenefit().getBenefitId(), PremiumPaymentResponseDTO::setBenefitId);
        });

        // ClaimPayment to DTO mapping
        TypeMap<ClaimPayment, ClaimPaymentResponseDTO> typeMapc = 
            mapper.createTypeMap(ClaimPayment.class, ClaimPaymentResponseDTO.class);

        typeMapc.addMappings(respc -> {
            respc.map(src -> src.getGroup().getGroupId(), ClaimPaymentResponseDTO::setGroupId);
            respc.map(src -> src.getMember().getMemberId(), ClaimPaymentResponseDTO::setMemberId);
            respc.map(src -> src.getClaim().getClaimId(), ClaimPaymentResponseDTO::setClaimId);
        });

        // Enum Converters
        mapper.addConverter(ctx -> ctx.getSource() == null ? null 
            : ContributionType.valueOf(ctx.getSource().toUpperCase()), String.class, ContributionType.class);

        mapper.addConverter(ctx -> ctx.getSource() == null ? null 
            : ClaimStatus.valueOf(ctx.getSource().toUpperCase()), String.class, ClaimStatus.class);

        mapper.addConverter(ctx -> ctx.getSource() == null ? null 
            : PaymentFrequency.valueOf(ctx.getSource().toUpperCase()), String.class, PaymentFrequency.class);

        mapper.addConverter(ctx -> ctx.getSource() == null ? null 
            : PaymentProcessingStatus.valueOf(ctx.getSource().toUpperCase()), String.class, PaymentProcessingStatus.class);

        mapper.addConverter(ctx -> ctx.getSource() == null ? null 
            : PaymentStatus.valueOf(ctx.getSource().toUpperCase()), String.class, PaymentStatus.class);

        return mapper;
    }
}
