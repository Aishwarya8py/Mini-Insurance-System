package com.example.InsuranceSystem.Enums;

public enum PaymentFrequency {
	MONTHLY,
	ANNUALLY

}
