package com.example.InsuranceSystem.model;
import com.example.InsuranceSystem.Enums.ClaimStatus;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Entity
@Data
@Table(name="Insurance_Claim")
public class Claims {
	@Id
	@GeneratedValue(strategy =GenerationType.IDENTITY)
	private int claimId;
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="memeberId",nullable= false)
	private MemberCreation member;
	
	private int claimDate;
	private int claimAmount;
	@Enumerated(EnumType.STRING)
	@NotNull
	private ClaimStatus claimstatus;
	private String description;

	public int getClaimId() {
		return claimId;
	}
	public void setClaimId(int claimId) {
		this.claimId = claimId;
	}
	public MemberCreation getMember() {
		return member;
	}
	public void setMember(MemberCreation member) {
		this.member = member;
	}
	public int getClaimDate() {
		return claimDate;
	}
	public void setClaimDate(int claimDate) {
		this.claimDate = claimDate;
	}
	public int getClaimAmount() {
		return claimAmount;
	}
	public void setClaimAmount(int claimAmount) {
		this.claimAmount = claimAmount;
	}
	public ClaimStatus getClaimstatus() {
		return claimstatus;
	}
	public void setClaimstatus(ClaimStatus claimstatus) {
		this.claimstatus = claimstatus;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
}
