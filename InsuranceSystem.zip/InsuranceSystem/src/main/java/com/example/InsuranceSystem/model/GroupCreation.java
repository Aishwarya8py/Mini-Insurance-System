package com.example.InsuranceSystem.model;

import com.example.InsuranceSystem.Enums.ContributionType;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;

@Entity
public class GroupCreation {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int groupId;
	private String groupName;
	private String creationDate;
	private String CoverageDetails;
	@Enumerated(EnumType.STRING)
	@Column(name="contri")
	private ContributionType contributionType;
	private String groupType;
	@OneToOne(cascade = CascadeType.ALL)  // <--- Add this line
	@JoinColumn(name = "contact_id")
	private ContactDetails contact;

	
	public int getGroupId() {
		return groupId;
	}
	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}
	public String getCoverageDetails() {
		return CoverageDetails;
	}
	public void setCoverageDetails(String coverageDetails) {
		CoverageDetails = coverageDetails;
	}
	public ContributionType getContributionType() {
		return contributionType;
	}
	public void setContributionType(ContributionType contributionType) {
		this.contributionType = contributionType;
	}
	public String getGroupType() {
		return groupType;
	}
	public void setGroupType(String groupType) {
		this.groupType = groupType;
	}
	public ContactDetails getContact() {
		return contact;
	}
	public void setContact(ContactDetails contact) {
		this.contact = contact;
	}
	
	
	
	
}

