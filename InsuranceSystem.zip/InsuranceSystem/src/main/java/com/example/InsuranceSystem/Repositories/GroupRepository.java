package com.example.InsuranceSystem.Repositories;

//import org.hibernate.boot.beanvalidation.GroupsPerOperation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.InsuranceSystem.model.GroupCreation;

@Repository
public interface GroupRepository extends JpaRepository<GroupCreation,Integer>{

	//GroupCreation save(GroupCreation group);

}
