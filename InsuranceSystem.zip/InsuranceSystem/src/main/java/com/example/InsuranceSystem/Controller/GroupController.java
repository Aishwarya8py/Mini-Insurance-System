package com.example.InsuranceSystem.Controller;

import com.example.InsuranceSystem.DTO.GroupRequestDTO;
import com.example.InsuranceSystem.DTO.GroupResponseDTO;
import com.example.InsuranceSystem.Service.GroupService;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/api/groups")
public class GroupController {

    @Autowired
    private GroupService groupService;

    // ✅ CREATE
    @PostMapping("/createGroup")
    public ResponseEntity<GroupResponseDTO> createGroup(@Valid @RequestBody GroupRequestDTO requestDTO) {
        try {
            GroupResponseDTO created = groupService.createGroup(requestDTO);
            return new ResponseEntity<>(created, HttpStatus.CREATED);
        } catch (RuntimeException ex) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, ex.getMessage());
        }
    }

    // ✅ READ ALL
    @GetMapping("/getAllGroup")
    public ResponseEntity<List<GroupResponseDTO>> getAllGroups() {
        return ResponseEntity.ok(groupService.getAllGroups());
    }

    // ✅ READ BY ID
    @GetMapping("/getGroupbygroupId/{groupId}")
    public ResponseEntity<GroupResponseDTO> getGroupById(@PathVariable int groupId) {
        try {
            return ResponseEntity.ok(groupService.getGroupById(groupId));
        } catch (RuntimeException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, ex.getMessage());
        }
    }

    // ✅ UPDATE
    @PutMapping("/updateGroup/{groupId}")
    public ResponseEntity<GroupResponseDTO> updateGroup(
            @PathVariable int groupId,
            @Valid @RequestBody GroupRequestDTO requestDTO) {
        try {
            GroupResponseDTO updated = groupService.updateGroup(groupId, requestDTO);
            return ResponseEntity.ok(updated);
        } catch (RuntimeException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, ex.getMessage());
        }
    }

    // ✅ DELETE
    @DeleteMapping("/deletegroup/{groupId}")
    public ResponseEntity<String> deleteGroup(@PathVariable int groupId) {
        try {
            groupService.DeleteGroup(groupId);
            return ResponseEntity.ok("Group with ID " + groupId + " deleted successfully.");
        } catch (RuntimeException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, ex.getMessage());
        }
    }
}
