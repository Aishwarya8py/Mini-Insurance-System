package com.example.InsuranceSystem.Enums;

public enum ClaimStatus {
	OPEN,
	APPROVED,
	REJECTED

}
