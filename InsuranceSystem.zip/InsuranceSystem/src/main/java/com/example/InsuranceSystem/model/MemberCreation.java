package com.example.InsuranceSystem.model;

//import jakarta.persistence.Column;
import jakarta.persistence.Entity;

//import jakarta.persistence.EnumType;
//import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;
@Entity
@Data
@Table(name="Insurance_Member")
public class MemberCreation {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int memberId;
	@ManyToOne(fetch= FetchType.LAZY)
	@JoinColumn(name ="group_id", nullable = false)
	private GroupCreation group;
	
	private String memberName;
	private String dob;
	private String enrollmentDate;
	private String status;
	
	public int getMemberId() {
		return memberId;
	}
	public void setMemberId(int memberId) {
		this.memberId = memberId;
	}
	public GroupCreation getGroup() {
		return group;
	}
	public void setGroup(GroupCreation group) {
		this.group = group;
	}
	public String getMemberName() {
		return memberName;
	}
	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getEnrollmentDate() {
		return enrollmentDate;
	}
	public void setEnrollmentDate(String enrollmentDate) {
		this.enrollmentDate = enrollmentDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	

}
