package com.example.InsuranceSystem.DTO;

import com.example.InsuranceSystem.Enums.ContributionType;
import com.example.InsuranceSystem.Enums.PaymentFrequency;
import com.example.InsuranceSystem.Enums.PaymentProcessingStatus;


public class PremiumPaymentRequestDTO {
	private int premiumPaymentDate;

	public int getPremiumPaymentDate() {
		return premiumPaymentDate;
	}
	public void setPremiumPaymentDate(int premiumPaymentDate) {
		this.premiumPaymentDate = premiumPaymentDate;
	}
	public double getPaymentAmount() {
		return paymentAmount;
	}
	public void setPaymentAmount(double paymentAmount) {
		this.paymentAmount = paymentAmount;
	}
	public PaymentFrequency getPaymentFrequency() {
		return paymentFrequency;
	}
	public void setPaymentFrequency(PaymentFrequency paymentFrequency) {
		this.paymentFrequency = paymentFrequency;
	}
	public ContributionType getContributionType() {
		return contributionType;
	}
	public void setContributionType(ContributionType contributionType) {
		this.contributionType = contributionType;
	}
	public PaymentProcessingStatus getPaymentProcessingStatus() {
		return paymentProcessingStatus;
	}
	public void setPaymentProcessingStatus(PaymentProcessingStatus paymentProcessingStatus) {
		this.paymentProcessingStatus = paymentProcessingStatus;
	}
	
	
	public int getGroupId() {
		return groupId;
	}
	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}
	public int getMemberId() {
		return memberId;
	}
	public void setMemberId(int memberId) {
		this.memberId = memberId;
	}
	public int getBenefitId() {
		return benefitId;
	}
	public void setBenefitId(int benefitId) {
		this.benefitId = benefitId;
	}
	private double paymentAmount;
	private PaymentFrequency paymentFrequency;

	private ContributionType contributionType;
	private PaymentProcessingStatus paymentProcessingStatus;
	private int groupId;
    private int memberId;
	private int benefitId;


}
